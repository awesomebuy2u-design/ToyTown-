import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ToyTownWorld extends StatefulWidget {
  const ToyTownWorld({super.key, required this.openListings, required this.openParent});
  final VoidCallback openListings;
  final VoidCallback openParent;

  @override
  State<ToyTownWorld> createState() => _ToyTownWorldState();
}

class _ToyTownWorldState extends State<ToyTownWorld> {
  static const int decorationPrice = 5;
  static const progressKey = 'toytown.world.progress';
  final storage = SharedPreferencesAsync();
  bool ready = false;
  bool saving = false;
  String? error;
  int tab = 0;
  int stars = 0;
  int careCount = 0;
  int? lastCareDay;
  bool decorated = false;

  int get today {
    final now = DateTime.now();
    return DateTime.utc(now.year, now.month, now.day)
        .difference(DateTime.utc(1970)).inDays;
  }

  @override
  void initState() {
    super.initState();
    loadProgress();
  }

  Future<void> loadProgress() async {
    try {
      final saved = await storage.getString(progressKey);
      final data = saved == null
          ? <String, dynamic>{}
          : jsonDecode(saved) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        stars = data['stars'] as int? ?? 0;
        careCount = data['careCount'] as int? ?? 0;
        lastCareDay = data['lastCareDay'] as int?;
        decorated = data['decorated'] as bool? ?? false;
        ready = true;
        error = null;
      });
    } catch (_) {
      if (mounted) setState(() => error = 'Не вдалося завантажити прогрес.');
    }
  }

  Future<void> saveProgress({
    required int newStars,
    required int newCareCount,
    required int? newLastCareDay,
    required bool newDecorated,
  }) async {
    if (!ready || saving) return;
    setState(() {
      saving = true;
      error = null;
    });
    try {
      await storage.setString(progressKey, jsonEncode({
        'stars': newStars,
        'careCount': newCareCount,
        'lastCareDay': newLastCareDay,
        'decorated': newDecorated,
      }));
      if (!mounted) return;
      setState(() {
        stars = newStars;
        careCount = newCareCount;
        lastCareDay = newLastCareDay;
        decorated = newDecorated;
      });
    } catch (_) {
      if (mounted) setState(() => error = 'Не вдалося зберегти прогрес. Спробуйте ще раз.');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> care() async {
    final day = today;
    if (lastCareDay != null && lastCareDay! >= day) return;
    await saveProgress(
      newStars: stars + 3,
      newCareCount: careCount + 1,
      newLastCareDay: day,
      newDecorated: decorated,
    );
  }

  Future<void> decorate() async {
    if (decorated || stars < decorationPrice) return;
    await saveProgress(
      newStars: stars - decorationPrice,
      newCareCount: careCount,
      newLastCareDay: lastCareDay,
      newDecorated: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('ToyTown · ⭐ $stars')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            if (error != null) Text(error!),
            if (!ready && error != null)
              TextButton(onPressed: loadProgress, child: const Text('Повторити')),
            ...(tab == 0 ? [
            Text('Містечко іграшок', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 16),
            FilledButton.tonal(onPressed: widget.openListings, child: const Text('🧸 Знайти іграшки')),
            FilledButton.tonal(onPressed: () => setState(() => tab = 1), child: const Text('🐾 Відвідати улюбленця')),
            TextButton(onPressed: widget.openParent, child: const Text('Кабінет батьків')),
          ] : tab == 1 ? [
            Text('Мій улюбленець', style: Theme.of(context).textTheme.headlineMedium),
            AnimatedSwitcher(
              duration: MediaQuery.disableAnimationsOf(context) ? Duration.zero : const Duration(milliseconds: 300),
              child: Text(careCount >= 3 ? '🐕' : '🐶',
                key: ValueKey(careCount >= 3), style: const TextStyle(fontSize: 88)),
            ),
            Text(careCount >= 3 ? 'Улюбленець підріс!' : 'Догляд до дорослішання: $careCount із 3 днів'),
            FilledButton(
              onPressed: !ready || saving || (lastCareDay ?? -1) >= today ? null : care,
              child: Text(lastCareDay == today ? 'Наступний догляд завтра' : 'Подбати про улюбленця · +3 ⭐'),
            ),
          ] : [
            Text('Моя крамничка', style: Theme.of(context).textTheme.headlineMedium),
            AnimatedContainer(
              duration: MediaQuery.disableAnimationsOf(context) ? Duration.zero : const Duration(milliseconds: 350),
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                color: decorated ? Colors.amber.shade100 : Colors.lightBlue.shade50,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Text(decorated ? '🎈 🏪 🎈' : '🏪', textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 56)),
            ),
            FilledButton(
              onPressed: !ready || saving || decorated || stars < decorationPrice ? null : decorate,
              child: Text(decorated ? 'Крамничку прикрашено' : 'Додати кульки · 5 ⭐'),
            ),
          ]),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (index) => setState(() => tab = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Містечко'),
          NavigationDestination(icon: Icon(Icons.pets), label: 'Улюбленець'),
          NavigationDestination(icon: Icon(Icons.storefront), label: 'Крамничка'),
        ],
      ),
    );
  }
}
