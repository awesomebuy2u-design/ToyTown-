package ua.toytown.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
