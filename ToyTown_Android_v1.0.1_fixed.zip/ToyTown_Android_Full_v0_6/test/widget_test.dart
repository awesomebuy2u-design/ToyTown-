import 'package:flutter_test/flutter_test.dart';
import 'package:toytown/main.dart';

void main() {
  testWidgets('shows setup screen when Supabase compile-time config is absent', (tester) async {
    await tester.pumpWidget(const ToyTownApp());
    expect(find.text('ToyTown'), findsOneWidget);
    expect(find.textContaining('додайте URL'), findsOneWidget);
  });
}
