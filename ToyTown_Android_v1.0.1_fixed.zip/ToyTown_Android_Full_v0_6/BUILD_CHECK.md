# ToyTown v1.0.0 — перевірка перед Android-релізом

## Що є у збірці
- Flutter Android app, version `1.0.0+10`.
- Каталог з пошуком і фільтрами; приватні чати; угоди обміну; профіль родини; сповіщення.
- Нове: приватні закладки оголошень родини та окремий екран «Збережені оголошення».
- Supabase migrations: `0001_initial_schema.sql` … `0005_saved_listings.sql`.

## Порядок запуску бази даних
Застосуйте SQL-файли послідовно у Supabase SQL Editor: `0001_initial_schema.sql`, `0002_family_notifications.sql`, `0003_private_family_chat.sql`, `0004_exchange_agreements.sql`, `0005_saved_listings.sql`.

## Налаштування та збірка
Використовуйте лише публічний Supabase publishable/anon key як build-time define. Ніколи не додавайте `service_role` у мобільний застосунок.

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release --dart-define=SUPABASE_URL=YOUR_PROJECT_URL --dart-define=SUPABASE_ANON_KEY=YOUR_PUBLIC_KEY
```

Для Google Play перед публікацією налаштуйте підписання Android App Bundle, політику конфіденційності, Data safety, віковий рейтинг, іконку та скриншоти. Перевірте сценарії реєстрації, відновлення доступу, RLS усіх таблиць, модерацію, завантаження фото, чати та двостороннє підтвердження угод на тестових акаунтах.

## Статус середовища
Flutter SDK відсутній у середовищі створення. Тому `flutter analyze`, `flutter test` та APK/AAB збірка тут не виконувалися. ZIP перевіряється окремо на цілісність; це не замінює компіляцію та тестування на Android-пристрої.
