-- ToyTown v1.0.0: private family bookmarks for public listings.
create table if not exists public.saved_listings (
  family_id uuid not null references public.families(id) on delete cascade,
  listing_id uuid not null references public.listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (family_id, listing_id)
);

create index if not exists saved_listings_family_created_idx
  on public.saved_listings(family_id, created_at desc);

alter table public.saved_listings enable row level security;
revoke all on public.saved_listings from anon;
grant select, insert, delete on public.saved_listings to authenticated;

create policy "family members read their saved listings"
  on public.saved_listings for select to authenticated
  using (public.is_family_guardian(family_id));

create policy "family members save public listings"
  on public.saved_listings for insert to authenticated
  with check (
    public.is_family_guardian(family_id)
    and exists (select 1 from public.listings l where l.id = listing_id and l.status = 'approved')
  );

create policy "family members remove their saved listings"
  on public.saved_listings for delete to authenticated
  using (public.is_family_guardian(family_id));
