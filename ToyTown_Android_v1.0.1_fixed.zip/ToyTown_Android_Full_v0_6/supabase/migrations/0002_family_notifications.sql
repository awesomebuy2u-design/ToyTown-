-- ToyTown v0.7.6: secure in-app notifications for adult family accounts.
create table if not exists public.family_notifications (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  body text not null default '' check (char_length(body) <= 500),
  kind text not null default 'info' check (kind in ('info','approved','rejected')),
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists family_notifications_feed_idx on public.family_notifications(family_id, created_at desc);
alter table public.family_notifications enable row level security;
create policy "family members read own notifications" on public.family_notifications
  for select to authenticated using (public.is_family_guardian(family_id));
create policy "family members mark own notifications read" on public.family_notifications
  for update to authenticated using (public.is_family_guardian(family_id))
  with check (public.is_family_guardian(family_id));
revoke insert, delete on public.family_notifications from anon, authenticated;
grant select on public.family_notifications to authenticated;
grant update (is_read) on public.family_notifications to authenticated;

create or replace function public.notify_listing_status_change()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if TG_OP = 'INSERT' then
    insert into public.family_notifications(family_id,title,body,kind)
    values (new.family_id, 'Оголошення надіслано', '«' || left(new.title, 80) || '» очікує перевірки дорослим.', 'info');
  elsif old.status is distinct from new.status and new.status in ('approved','rejected') then
    insert into public.family_notifications(family_id,title,body,kind)
    values (new.family_id,
      case when new.status = 'approved' then 'Оголошення підтверджено' else 'Оголошення відхилено' end,
      'Статус оголошення «' || left(new.title, 80) || '» змінено. ' || coalesce(new.moderation_note,''),
      new.status);
  end if;
  return new;
end; $$;
drop trigger if exists listings_notify_family on public.listings;
create trigger listings_notify_family after insert or update of status on public.listings
for each row execute function public.notify_listing_status_change();
