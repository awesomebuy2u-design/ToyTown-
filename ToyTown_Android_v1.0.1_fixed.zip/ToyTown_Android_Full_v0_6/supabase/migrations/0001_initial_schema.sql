-- ToyTown v0.6 — initial Supabase schema.
-- Apply in Supabase SQL Editor. Do not put service_role keys in the mobile app.

create extension if not exists pgcrypto;

create table if not exists public.families (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 80),
  guardian_name text not null check (char_length(guardian_name) between 1 and 80),
  city text not null check (char_length(city) between 2 and 80),
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.family_members (
  family_id uuid not null references public.families(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'guardian' check (role in ('guardian','co_guardian')),
  created_at timestamptz not null default now(),
  primary key (family_id,user_id)
);


create or replace function public.is_family_creator(target_family uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.families f where f.id = target_family and f.created_by = auth.uid());
$$;

create table if not exists public.child_profiles (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  nickname text not null check (char_length(nickname) between 1 and 32),
  age_band text not null check (age_band in ('under_6','6_8','9_12','13_17')),
  created_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  family_id uuid not null references public.families(id) on delete cascade,
  child_profile_id uuid references public.child_profiles(id) on delete set null,
  title text not null check (char_length(title) between 2 and 80),
  description text not null default '' check (char_length(description) <= 1000),
  category text not null default 'Інше',
  condition text not null check (condition in ('new','used')),
  deal_type text not null check (deal_type in ('gift','exchange','sale')),
  city text not null check (char_length(city) between 2 and 80),
  price integer check (price is null or price >= 0),
  photo_path text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','archived')),
  moderation_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.listing_reports (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  reporter_user_id uuid not null references auth.users(id) on delete cascade,
  reason text not null check (char_length(reason) between 3 and 500),
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now(),
  unique(listing_id, reporter_user_id)
);

create table if not exists public.partner_stores (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  website_url text,
  city text,
  is_active boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.partner_products (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.partner_stores(id) on delete cascade,
  title text not null,
  product_url text not null,
  image_url text,
  is_active boolean not null default false,
  created_at timestamptz not null default now()
);

-- Public catalogue view exposes only fields safe for public browsing.
-- Never grant anonymous SELECT on the base listings table: it contains family and child IDs.
create or replace view public.public_listings
with (security_barrier = true) as
select id, title, description, category, condition, deal_type, city, price, photo_path, created_at
from public.listings
where status = 'approved';

revoke all on public.listings from anon;
grant select on public.listings to authenticated;
grant select on public.public_listings to anon, authenticated;

create index if not exists listings_status_created_idx on public.listings(status, created_at desc);
create index if not exists listings_family_idx on public.listings(family_id);
create index if not exists child_profiles_family_idx on public.child_profiles(family_id);

create or replace function public.is_family_guardian(target_family uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.family_members fm
    where fm.family_id = target_family and fm.user_id = auth.uid()
  );
$$;

create or replace function public.approve_listing(target_listing uuid, approve boolean, note text default null)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare target_family uuid;
begin
  select family_id into target_family from public.listings where id = target_listing;
  if target_family is null or not public.is_family_guardian(target_family) then
    raise exception 'Not authorized';
  end if;
  update public.listings
    set status = case when approve then 'approved' else 'rejected' end,
        moderation_note = left(coalesce(note,''),500),
        updated_at = now()
    where id = target_listing and status = 'pending';
  if not found then raise exception 'Listing not found or no longer pending'; end if;
end;
$$;

alter table public.families enable row level security;
alter table public.family_members enable row level security;
alter table public.child_profiles enable row level security;
alter table public.listings enable row level security;
alter table public.listing_reports enable row level security;
alter table public.partner_stores enable row level security;
alter table public.partner_products enable row level security;

create policy "family members can read their family"
on public.families for select to authenticated
using (public.is_family_guardian(id));
create policy "authenticated users can create family"
on public.families for insert to authenticated
with check (created_by = auth.uid());
create policy "family members can update their family"
on public.families for update to authenticated
using (public.is_family_guardian(id))
with check (public.is_family_guardian(id));

create policy "members can read memberships in own family"
on public.family_members for select to authenticated
using (public.is_family_guardian(family_id));
create policy "creator can add self as guardian"
on public.family_members for insert to authenticated
with check (user_id = auth.uid() and role = 'guardian' and public.is_family_creator(family_id));

create policy "family members manage child profiles"
on public.child_profiles for all to authenticated
using (public.is_family_guardian(family_id))
with check (public.is_family_guardian(family_id));

create policy "public can read approved listings"
on public.listings for select to anon, authenticated
using (status = 'approved');
create policy "family members can read own listings"
on public.listings for select to authenticated
using (public.is_family_guardian(family_id));
create policy "family members can create pending listings"
on public.listings for insert to authenticated
with check (public.is_family_guardian(family_id) and status = 'pending');
create policy "family members can edit own listings"
on public.listings for update to authenticated
using (public.is_family_guardian(family_id) and status in ('pending','rejected'))
with check (public.is_family_guardian(family_id) and status in ('pending','rejected'));
create policy "family members can delete own pending listings"
on public.listings for delete to authenticated
using (public.is_family_guardian(family_id) and status in ('pending','rejected'));

create policy "users can report listings"
on public.listing_reports for insert to authenticated
with check (reporter_user_id = auth.uid());
create policy "reporters can view own reports"
on public.listing_reports for select to authenticated
using (reporter_user_id = auth.uid());

create policy "active partner stores public"
on public.partner_stores for select to anon, authenticated using (is_active = true);
create policy "active partner products public"
on public.partner_products for select to anon, authenticated using (is_active = true);

grant execute on function public.approve_listing(uuid, boolean, text) to authenticated;
grant execute on function public.is_family_guardian(uuid) to authenticated;
grant execute on function public.is_family_creator(uuid) to authenticated;

-- Private bucket. Images are not publicly enumerable. Use signed URLs in production.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('listing-images','listing-images',false,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "family members upload listing images"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'listing-images'
  and public.is_family_guardian(((storage.foldername(name))[1])::uuid)
);
create policy "family members read their listing images"
on storage.objects for select to authenticated
using (
  bucket_id = 'listing-images'
  and public.is_family_guardian(((storage.foldername(name))[1])::uuid)
);
create policy "family members delete their listing images"
on storage.objects for delete to authenticated
using (
  bucket_id = 'listing-images'
  and public.is_family_guardian(((storage.foldername(name))[1])::uuid)
);
