-- ToyTown v0.8.0: adult-only private family conversations.
create table if not exists public.family_conversations (
  id uuid primary key default gen_random_uuid(),
  family_a uuid not null references public.families(id) on delete cascade,
  family_b uuid not null references public.families(id) on delete cascade,
  listing_id uuid references public.listings(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint family_conversations_distinct_families check (family_a <> family_b)
);
create index if not exists family_conversations_a_idx on public.family_conversations(family_a, updated_at desc);
create index if not exists family_conversations_b_idx on public.family_conversations(family_b, updated_at desc);

create table if not exists public.family_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.family_conversations(id) on delete cascade,
  sender_user_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);
create index if not exists family_messages_conversation_idx on public.family_messages(conversation_id, created_at);

create or replace function public.is_conversation_member(target_conversation uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.family_conversations c
    where c.id = target_conversation
      and (public.is_family_guardian(c.family_a) or public.is_family_guardian(c.family_b))
  );
$$;

-- A guardian can start a conversation from an approved public listing, but cannot contact their own family.
create or replace function public.start_listing_conversation(target_listing uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare my_family uuid; owner_family uuid; conversation uuid;
begin
  select fm.family_id into my_family from public.family_members fm where fm.user_id = auth.uid() limit 1;
  if my_family is null then raise exception 'Create a family profile first'; end if;
  select l.family_id into owner_family from public.listings l where l.id = target_listing and l.status = 'approved';
  if owner_family is null then raise exception 'Listing is unavailable'; end if;
  if owner_family = my_family then raise exception 'Cannot start a conversation with your own family'; end if;
  select c.id into conversation from public.family_conversations c
    where c.listing_id = target_listing and c.family_a = least(my_family,owner_family) and c.family_b = greatest(my_family,owner_family)
    limit 1;
  if conversation is null then
    insert into public.family_conversations(family_a,family_b,listing_id)
    values(least(my_family,owner_family),greatest(my_family,owner_family),target_listing)
    returning id into conversation;
  end if;
  return conversation;
end; $$;

create or replace function public.touch_conversation_from_message()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update public.family_conversations set updated_at = now() where id = new.conversation_id;
  return new;
end; $$;
drop trigger if exists family_message_touch_conversation on public.family_messages;
create trigger family_message_touch_conversation after insert on public.family_messages
for each row execute function public.touch_conversation_from_message();

alter table public.family_conversations enable row level security;
alter table public.family_messages enable row level security;
create policy "adult family members read their conversations" on public.family_conversations
  for select to authenticated using (public.is_family_guardian(family_a) or public.is_family_guardian(family_b));
create policy "adult family members read conversation messages" on public.family_messages
  for select to authenticated using (public.is_conversation_member(conversation_id));
create policy "adult family members send messages as themselves" on public.family_messages
  for insert to authenticated with check (
    sender_user_id = auth.uid() and public.is_conversation_member(conversation_id)
  );
revoke all on public.family_conversations from anon;
revoke all on public.family_messages from anon;
grant select on public.family_conversations to authenticated;
grant select, insert on public.family_messages to authenticated;
grant execute on function public.start_listing_conversation(uuid) to authenticated;
grant execute on function public.is_conversation_member(uuid) to authenticated;
