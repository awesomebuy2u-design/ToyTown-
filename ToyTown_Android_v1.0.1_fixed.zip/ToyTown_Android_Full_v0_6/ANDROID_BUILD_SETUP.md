# Android build setup — ToyTown 1.0.1

## Recommended: cloud build
Use `.github/workflows/android-apk.yml` and follow `GITHUB_ACTIONS_BUILD.md`.
The workflow provisions Flutter, Java 17 and Android tooling on GitHub-hosted runners,
generates Android platform files if needed, runs analysis and tests, and uploads
the release APK as a workflow artifact.

## Local build
Requirements: Flutter stable (Dart 3.3+), Android SDK, and JDK 17.

```bash
flutter create --platforms=android --org ua.toytown .
flutter pub get
flutter analyze
flutter test
flutter build apk --release \
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=YOUR_PUBLIC_PUBLISHABLE_OR_ANON_KEY
```

Never place a Supabase `service_role` key in the Android app. Do not commit
`android/local.properties`, keystores, or signing passwords.
