## 1.0.1 — Android build preparation
- Added GitHub Actions workflow for Flutter analysis, tests and release APK build.
- Added cloud-build setup instructions and secure Supabase secret configuration.
- APK is produced by the workflow after the project is pushed to GitHub; no APK is embedded in this source archive.

# ToyTown changelog

## 0.7.5
- Added catalog text search across toy title, description, and city.
- Added category and listing-format filters (gift, exchange, sale).
- Added pull-to-refresh to the public catalog.
- Added an explicit empty state when filters return no results.

## 0.7.4
- Added Android Gradle configuration, MainActivity, manifest, and widget test foundation.


## v0.7.6
- Додано приватні внутрішні сповіщення для дорослого акаунта родини.
- Сповіщення автоматично створюються після надсилання оголошення та після рішення модерації.
- Додано список останніх 30 сповіщень і позначення прочитаних.
- Додано окрему Supabase-міграцію `0002_family_notifications.sql`.

## v0.8.0
- Додано приватні розмови між дорослими представниками двох родин.
- Ініціювати розмову можна безпосередньо з картки опублікованого оголошення.
- Додано шаблони повідомлень для пропозиції обміну, дарування та узгодження безпечної передачі.
- Доступ до розмов і повідомлень обмежено учасниками родин через Supabase RLS.
- Додано міграцію `0003_private_family_chat.sql` та серверну функцію створення розмови з перевіркою власника оголошення.
- Чати не доступні дитячим профілям; не передавайте домашні адреси та персональні дані дітей.


## v0.9.0
- Додано окремий розділ «Угоди» для домовленостей між родинами.
- Із приватного чату можна створити пропозицію домовленості з описом умов.
- Друга родина може прийняти або відхилити пропозицію.
- Передача вважається завершеною лише після підтвердження обома дорослими сторонами.
- Додано RLS та серверні RPC-перевірки учасників родин і статусів угоди.
- Додано міграцію `0004_exchange_agreements.sql`.

## v1.0.0
- Перший релізний кандидат ToyTown для Android.
- Додано приватні закладки оголошень на рівні родини: збереження, перегляд окремим списком і видалення із закладок.
- Закладки доступні лише дорослим учасникам відповідної родини; зберігати можна лише опубліковані оголошення.
- Додано Supabase-міграцію `0005_saved_listings.sql` та індекс для швидкого завантаження.
- Підготовлено чекліст перевірок перед публікацією Android-збірки.
