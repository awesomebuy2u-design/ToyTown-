# ToyTown Android — v0.7

Flutter + Supabase foundation for a parent-supervised toy exchange app.

## v0.7 changes
- Added a parent moderation queue in the app.
- Guardians can approve or reject pending family listings through the existing secured `approve_listing` RPC.
- Added user-facing safety reminders before approving a listing.
- Kept Supabase URL and publishable key as build-time defines; never embed `service_role`.

See `SUPABASE_SETUP.md` for setup, build and verification steps. This is a development build, not a production-certified app.


### Оновлення v0.7.6
Застосуйте `supabase/migrations/0002_family_notifications.sql` у Supabase SQL Editor після міграції `0001_initial_schema.sql`. Після цього в розділі «Родина» з'являться внутрішні сповіщення про надсилання та модерацію оголошень.

## Версія 0.8.0 — приватні чати

Для роботи чатів застосуйте міграцію `supabase/migrations/0003_private_family_chat.sql` після міграцій 0001 та 0002. Дорослий користувач може почати розмову з картки опублікованого оголошення. Повідомлення доступні лише двом родинам-учасникам через RLS. Дитячі профілі не мають окремого входу чи доступу до чатів. Не надсилайте домашні адреси, телефони дітей або інші персональні дані.


### Оновлення v0.9.0
Після застосування міграцій `0001`–`0003` виконайте `supabase/migrations/0004_exchange_agreements.sql` у Supabase SQL Editor. У чаті натисніть значок рукостискання, щоб створити пропозицію; обидві родини мають підтвердити фактичну передачу для завершення угоди.

### Версія 1.0.0 — перший релізний кандидат
- У каталозі натисніть значок закладки на оголошенні, щоб зберегти його для родини.
- Відкрийте «Збережені оголошення» над пошуком, щоб переглянути список; список можна оновити свайпом вниз.
- Закладки синхронізуються між дорослими учасниками однієї родини та захищені RLS.
- Застосуйте `supabase/migrations/0005_saved_listings.sql` після міграцій `0001`–`0004`.
