# ToyTown Android build via GitHub Actions

## What this does
The workflow in `.github/workflows/android-apk.yml` provisions Flutter, Java 17 and Android tooling, generates Android platform files if needed, resolves packages, runs `flutter analyze` and `flutter test`, builds a release APK, and publishes it as a downloadable workflow artifact.

## One-time setup
1. Create a **private** GitHub repository and upload the contents of this project.
2. In the repository open **Settings → Secrets and variables → Actions**.
3. Add:
   - `SUPABASE_URL` — the Supabase Project URL.
   - `SUPABASE_ANON_KEY` — the public Publishable key or legacy anon key. Never use `service_role` or a secret key in a mobile app.
4. Open **Actions → Build Android APK → Run workflow**.
5. When the workflow finishes, download `toytown-android-release` from the run's **Artifacts** section.

## Notes
- This workflow creates an unsigned APK suitable for device testing. Google Play production distribution requires a protected upload keystore and signing secrets.
- If Supabase secrets are omitted, the build may complete but online initialization will not be configured.
- A successful workflow run is the evidence that analysis, tests and APK build succeeded. This source archive itself is not an APK.
