import 'package:flutter_test/flutter_test.dart';
import 'package:toytown/main.dart';

void main() {
  testWidgets('opens the town without Supabase and keeps online setup accessible',
      (tester) async {
    await tester.pumpWidget(const ToyTownApp());
    expect(find.text('Містечко іграшок'), findsOneWidget);
    await tester.tap(find.text('Кабінет батьків'));
    await tester.pumpAndSettle();
    expect(find.textContaining('додайте URL'), findsOneWidget);
  });
}
