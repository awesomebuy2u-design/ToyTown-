import 'dart:convert';
import 'dart:async';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ToyTownWorld extends StatefulWidget {
  const ToyTownWorld({super.key, required this.openListings, required this.openParent, this.client});
  final SupabaseClient? client;
  final VoidCallback openListings;
  final VoidCallback openParent;

  @override
  State<ToyTownWorld> createState() => _ToyTownWorldState();
}

class _ToyTownWorldState extends State<ToyTownWorld> with WidgetsBindingObserver {
  static const int decorationPrice = 5;
  static const progressKey = 'toytown.world.progress';
  static const ownerKey = 'toytown.world.legacyFamily';
  final storage = SharedPreferencesAsync();
  StreamSubscription<AuthState>? authSubscription;
  bool ready = false, saving = false, canCare = true, cloudStored = false;
  String? error, familyId, accountId;
  Map<String, dynamic>? legacyProgress;
  int generation = 0;
  int tab = 0, stars = 0, careCount = 0;
  int? lastCareDay;
  bool decorated = false;
  bool get online => widget.client?.auth.currentUser != null;

  int get today {
    final now = DateTime.now();
    return DateTime.utc(now.year, now.month, now.day)
        .difference(DateTime.utc(1970)).inDays;
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    accountId = widget.client?.auth.currentUser?.id;
    authSubscription = widget.client?.auth.onAuthStateChange.listen((state) {
      final next = state.session?.user.id;
      if (next != accountId) {
        accountId = next;
        loadProgress();
      }
    }, onError: (Object _) {
      if (mounted) setState(() => error = 'Перевірте з’єднання та оновіть прогрес.');
    });
    loadProgress();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    authSubscription?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !saving) loadProgress();
  }

  void applyProgress(Map<String, dynamic> data) {
    stars = (data['stars'] as num?)?.toInt() ?? 0;
    careCount = (data['careCount'] as num?)?.toInt() ?? 0;
    lastCareDay = (data['lastCareDay'] as num?)?.toInt();
    decorated = data['decorated'] == true;
    familyId = data['familyId'] as String?;
    cloudStored = data['stored'] == true;
    canCare = online ? data['canCare'] == true : (lastCareDay ?? -1) < today;
  }

  bool current(int ticket, String? user) => mounted && ticket == generation && user == widget.client?.auth.currentUser?.id;

  Future<String> guestKey() async => await storage.getString(ownerKey) == null ? progressKey : '$progressKey.guest';

  Future<void> loadProgress() async {
    final ticket = ++generation;
    final user = widget.client?.auth.currentUser?.id;
    setState(() {
      ready = false; saving = false; error = null; legacyProgress = null;
      stars = 0; careCount = 0; lastCareDay = null; decorated = false;
      familyId = null; cloudStored = false;
    });
    try {
      Map<String, dynamic> data;
      Map<String, dynamic>? local;
      if (user != null) {
        data = Map<String, dynamic>.from(await widget.client!.rpc('family_world_action'));
        final owner = await storage.getString(ownerKey);
        if (data['stored'] != true && (owner == null || owner == data['familyId'])) {
          final raw = await storage.getString(progressKey);
          if (raw != null) {
            final parsed = Map<String, dynamic>.from(jsonDecode(raw) as Map);
            if (((parsed['careCount'] as num?)?.toInt() ?? 0) > 0) local = parsed;
          }
        }
      } else {
        final raw = await storage.getString(await guestKey());
        data = raw == null ? <String, dynamic>{} : Map<String, dynamic>.from(jsonDecode(raw) as Map);
      }
      if (!current(ticket, user)) return;
      setState(() { applyProgress(data); legacyProgress = local; ready = true; });
    } catch (_) {
      if (current(ticket, user)) setState(() => error = user == null
        ? 'Не вдалося завантажити локальний прогрес.'
        : 'Не вдалося завантажити прогрес родини. Перевірте інтернет і створіть родину в кабінеті батьків.');
    }
  }

  Future<void> act(String action) async {
    if (!ready || saving) return;
    final user = widget.client?.auth.currentUser?.id;
    final ticket = generation;
    final target = familyId;
    setState(() { saving = true; error = null; });
    try {
      Map<String, dynamic> data;
      if (user != null) {
        if (target == null) throw StateError('Family required');
        data = Map<String, dynamic>.from(await widget.client!.rpc('family_world_action', params: {
          'action': action, 'target_family': target,
        }));
      } else {
        data = <String, dynamic>{
          'stars': action == 'care' ? stars + 3 : stars - decorationPrice,
          'careCount': action == 'care' ? careCount + 1 : careCount,
          'lastCareDay': action == 'care' ? today : lastCareDay,
          'decorated': action == 'decorate' || decorated,
        };
        final key = await guestKey();
        if (!current(ticket, user)) return;
        await storage.setString(key, jsonEncode(data));
      }
      if (!current(ticket, user)) return;
      setState(() { applyProgress(data); legacyProgress = null; });
    } catch (_) {
      if (current(ticket, user)) setState(() => error = 'Дію не підтверджено. Оновіть прогрес перед повторною спробою.');
    } finally {
      if (current(ticket, user)) setState(() => saving = false);
    }
  }

  Future<void> importProgress() async {
    final user = widget.client?.auth.currentUser?.id;
    final target = familyId;
    final local = legacyProgress;
    final ticket = generation;
    if (user == null || target == null || local == null || saving || !ready) return;
    setState(() => saving = true);
    try {
      final confirmed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('Перенести прогрес у цю родину?'),
        content: const Text('Локальний улюбленець, зірочки та прикраса будуть прив’язані до родини поточного акаунта. Перенесення на цьому пристрої доступне лише для однієї родини.'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Назад')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Перенести'))],
      ));
      if (confirmed != true || !current(ticket, user)) return;
      final owner = await storage.getString(ownerKey);
      if (owner != null && owner != target) throw StateError('Already assigned');
      await storage.setString(ownerKey, target);
      if (!current(ticket, user)) return;
      final data = Map<String, dynamic>.from(await widget.client!.rpc('family_world_action', params: {
        'action': 'import', 'target_family': target, 'legacy': local,
      }));
      if (current(ticket, user)) setState(() { applyProgress(data); legacyProgress = null; error = null; });
    } catch (_) {
      if (current(ticket, user)) setState(() => error = 'Не вдалося перенести прогрес. Локальні дані збережені — спробуйте ще раз.');
    } finally {
      if (current(ticket, user)) setState(() => saving = false);
    }
  }

  Future<void> care() async {
    if (!canCare) return;
    await act('care');
  }

  Future<void> decorate() async {
    if (decorated || stars < decorationPrice) return;
    await act('decorate');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('ToyTown · ⭐ $stars'), actions: [IconButton(tooltip: 'Оновити прогрес', onPressed: saving ? null : loadProgress, icon: const Icon(Icons.refresh))]),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text(online ? (ready ? (cloudStored ? 'Прогрес родини збережено в акаунті' : 'Родину підключено. Новий прогрес зберігатиметься в акаунті.') : 'Завантаження прогресу родини…') : 'Гостьовий прогрес зберігається лише на цьому пристрої.'),
            if (!online) TextButton(onPressed: widget.openParent, child: const Text('Увійти для збереження в акаунті')),
            if (legacyProgress != null) ...[
              const Text('На пристрої є старий прогрес. Перенесіть його перед першим доглядом у цій родині.'),
              FilledButton.tonal(onPressed: saving ? null : importProgress, child: const Text('Перенести локальний прогрес у родину')),
            ],
            if (saving) const LinearProgressIndicator(),
            if (error != null) Text(error!),
            if (!ready && error != null)
              TextButton(onPressed: loadProgress, child: const Text('Повторити')),
            ...(tab == 0 ? [
            Text('Містечко іграшок', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 16),
            FilledButton.tonal(onPressed: widget.openListings, child: const Text('🧸 Знайти іграшки')),
            FilledButton.tonal(onPressed: () => setState(() => tab = 1), child: const Text('🐾 Відвідати улюбленця')),
            TextButton(onPressed: widget.openParent, child: const Text('Кабінет батьків')),
          ] : tab == 1 ? [
            Text('Мій улюбленець', style: Theme.of(context).textTheme.headlineMedium),
            AnimatedSwitcher(
              duration: MediaQuery.disableAnimationsOf(context) ? Duration.zero : const Duration(milliseconds: 300),
              child: Text(careCount >= 3 ? '🐕' : '🐶',
                key: ValueKey(careCount >= 3), style: const TextStyle(fontSize: 88)),
            ),
            Text(careCount >= 3 ? 'Улюбленець підріс!' : 'Догляд до дорослішання: $careCount із 3 днів'),
            FilledButton(
              onPressed: !ready || saving || !canCare || legacyProgress != null ? null : care,
              child: Text(!canCare ? 'Наступний догляд завтра' : 'Подбати про улюбленця · +3 ⭐'),
            ),
          ] : [
            Text('Моя крамничка', style: Theme.of(context).textTheme.headlineMedium),
            AnimatedContainer(
              duration: MediaQuery.disableAnimationsOf(context) ? Duration.zero : const Duration(milliseconds: 350),
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                color: decorated ? Colors.amber.shade100 : Colors.lightBlue.shade50,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Text(decorated ? '🎈 🏪 🎈' : '🏪', textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 56)),
            ),
            FilledButton(
              onPressed: !ready || saving || decorated || stars < decorationPrice ? null : decorate,
              child: Text(decorated ? 'Крамничку прикрашено' : 'Додати кульки · 5 ⭐'),
            ),
          ]),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (index) => setState(() => tab = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Містечко'),
          NavigationDestination(icon: Icon(Icons.pets), label: 'Улюбленець'),
          NavigationDestination(icon: Icon(Icons.storefront), label: 'Крамничка'),
        ],
      ),
    );
  }
}
