-- Keep listing-images private and allow signed URLs for approved photos.
begin;

drop policy if exists "signed-in users read approved listing images" on storage.objects;
create policy "signed-in users read approved listing images"
on storage.objects for select to authenticated
using (
  bucket_id = 'listing-images'
  and exists (
    select 1
    from public.listings as listing
    where listing.status = 'approved'
      and listing.photo_path = storage.objects.name
      and split_part(storage.objects.name, '/', 1) = listing.family_id::text
  )
);

notify pgrst, 'reload schema';
commit;
